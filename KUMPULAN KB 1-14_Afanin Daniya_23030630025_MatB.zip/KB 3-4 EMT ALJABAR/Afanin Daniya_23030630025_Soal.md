﻿# AFANIN DANIYA / 23030630025
# R.2 - Exercise Set

# No 49 

hasil


\>$&(((24\*a^10\*b^-8\*c^7)/(12\*a^6\*b^-3\*c^5))^-5)


Maka dapat dipastikan bahwa hasil penyelesaian benar.


# No 50

hasil


\> $&(((125\*p^12\*q^-14\*r^22)/(25\*p^8\*q^6\*r^-15))^-4)


Maka dapat dipastikan bahwa hasil penyelesaian benar.


# No 90

hasil


\> $&((2^6\*2^-3)/2^10/2^-8)


Maka dapat dipastikan bahwa hasil penyelesaian benar.


# No 91

hasil


\>$&((4\*(8-6)^2-(4\*3)+(2\*8))/(3^1+19^0))


Maka dapat dipastikan bahwa hasil penyelesaian benar.


# No 92

\>$&(([4\*(8-6)^2+4])/(2^2\*(2^3+5)))


Maka dapat dipastikan bahwa hasil penyelesaian benar.


# R.3 - Exercise Set

# No 7

hasil


\> $&((2\*x+3\*y+z-7)+(4\*x-2\*y-z+8)+(-3\*x+y-2\*z-4))


Maka dapat dipastikan bahwa hasil penyelesaian benar.


# No 8

hasil


\> $&((2\*x^2+12\*x\*y-11)+(6\*x^2-2\*x+4)+(-x^2-y-2))


Maka dapat dipastikan bahwa hasil penyelesaian benar.


# No 9

hasil


\>$&((3\*x^2-2\*x-x^3+2)-(5\*x^2-8\*x-x^3+4))


Maka dapat dipastikan bahwa hasil penyelesaian benar.


# No 29

hasil


\>$&expand((y-5)^2)


Maka dapat dipastikan bahwa hasil penyelesaian benar.


# No 31

\>$&expand((5\*x-3)^2)


Maka dapat dipastikan bahwa hasil penyelesaian benar.


# R.4 - Exercise Set

# No 23

hasil


\>$&factor(t^2+8\*t+15)


Maka dapat dipastikan bahwa hasil penyelesaian benar.


# No 24

hasil


\>$&factor(y^2+12\*y+27)


Maka dapat dipastikan bahwa hasil penyelesaian benar.


# No 85

\>$&factor(m^2-9\*n^2)


Maka dapat dipastikan bahwa hasil penyelesaian benar.


# No 100

\> $&factor(x^2\*y^2-16\*x\*y+64)


Maka dapat dipastikan bahwa hasil penyelesaian benar.


# No 106

\> $&factor(24\*a^2 \* x^4- 375\*a^8 \* x)


Maka dapat dipastikan bahwa hasil penyelesaian benar.


# R.5 - Exercise Set

# No 32

\>$&solve(9\*(2\*x+8)=20-(x+5))


# Soal No.33

\>$&solve(4\*(3\*y-1)-6=5\*(y+2))


# No 36

hasil


\>$&solve(y^2-4\*y-45=0)


Maka dapat dipastikan bahwa hasil penyelesaian benar.


# Soal No.50

\>$&solve(21\*n^2-10=n)


Maka dapat dipastikan bahwa hasil penyelesaian benar.


# Soal No.71

\>$&solve(7\*(3\*x+6)=11-(x+2))


Maka dapat dipastikan bahwa hasil penyelesaian benar.


# R.6 Exercise Set

# Soal No.9

\>$&solve((x^2-4)/(x^2-4\*x+4))


# Soal No.10 

\>$&solve((x^2+2\*x-3)/(x^2-9))


# Soal No.11

\>$&solve((x^3-6\*x^2+9\*x)/(x^3-3\*x^2))


# Soal No.12

\>$&solve((y^5-5\*y^4+4\*y^3)/(y^3-6\*y^2+8\*y))


    latex: \lvert x - 4 \rvert + 3 = 9
    latex: \lvert x - 4 \rvert = 6
    latex: x - 4 = 6 \quad \text{atau} \quad x - 4 = -6
    latex: x - 4 = 6
    latex: x = 6 + 4
    latex: x = 10
    latex: x - 4 = -6
    latex: x = -6 + 4
    latex: x = -2
    latex: x = 10 \quad \text{atau} \quad x = -2
    
    latex: \lvert x - 4 \rvert + 3 = 9
    latex: \lvert x - 4 \rvert = 6
    latex: x - 4 = 6 \quad \text{atau} \quad x - 4 = -6
    latex: x - 4 = 6
    latex: x = 6 + 4
    latex: x = 10
    latex: x - 4 = -6
    latex: x = -6 + 4
    latex: x = -2
    latex: x = 10 \quad \text{atau} \quad x = -2
    
    latex: \lvert x - 4 \rvert + 3 = 9
    latex: \lvert x - 4 \rvert = 6
    latex: x - 4 = 6 \quad \text{atau} \quad x - 4 = -6
    latex: x - 4 = 6
    latex: x = 6 + 4
    latex: x = 10
    latex: x - 4 = -6
    latex: x = -6 + 4
    latex: x = -2
    latex: x = 10 \quad \text{atau} \quad x = -2
    

# Soal No.13

\>$&solve((6\*y^2+12\*y-48)/(3\*y^2-9\*y+6))


# 3.5 Exercise Set

* Soal No.23


\>$&solve(abs(x+3)-2=8)


# Soal No.  24

\>$&solve(abs(x-4)+3=9)


# Soal No.25

\>$&solve(abs(3\*x+1)-4=-1)


# Soal No.30

\>$&solve(9-abs(x-2)=7)


# Soal No.32

\>$&solve(5-abs(4\*x+3)=2)


# 2.3 Exercise Set

# Soal no 39

\>$&solve(h(x)=(4+3\*x)^5)


# Soal No.41

\>$&solve(h(x)=1/(x-2)^4)


# Soal No. 46

\>$&solve(h(x)=(sqrt(x)-3)^4)


# Soal No.49

\>$&solve(h(x)=(x+2)^3-5\*(x+2)^2+3\*(x+2)-1)


# Soal No. 47

Fungsi ini sudah dalam bentuk yang paling sederhana dan tidak
memerlukan penyederhanaan lebih lanjut. Fungsi ini mengandung akar
kuadrat dari pecahan.


\> $&solve(h(x)=sqrt((x-5)/(x+2)))


# 3.1 Exercise Set

## Soal No. 11

\>(-5+3i)+(7+8i)


    2+11i

## Soal NO. 12

\>(-6-5i)+(9+2i)


    3-3i

## Soal NO. 13

\>(4-9i)+(1-3i)


    5-12i

## Soal No. 14

\>(7-2i)+(4-5i)


    11-7i

## Soal No. 15

\>(12+3i)+(-8+5i)


    4+8i

# 3.4 Exercise Set

## Soal No. 2

jadi, nilai x nya adalah -2


\>$&(1/3)-(5/6)=1/x


## Soal No. 1

jadi, nilai t nya adalah 20/9


\>$&(1/4)+(1/5)=1/t


## Soal No. 3

Jadi, nilai x = 32.67


\>$&solve(((x+2)/4)+((x-1)/5)=15)


## Soal No. 4

Jadi, nilai t adalah -1


\>$&solve(((t+1)/3)-((t-1)/2)=1)


## Soal No. 5

jadi, nilai x nya adalah 6


\>$&solve(((1/2)+(2/x))= ((1/3)+(3/x)))


# Chapter 3 Test

## Soal No. 11

* 
persamaan pertama: x+4=7


* 
persamaan kedua: x+4=-7


jadi, solusi dari persamaaan |x+4|=7 adalah x=3 atau x=-11


\>$&solve((abs(x+4)=7))


## Soal No. 12

* 
persamaan pertama: 4y-3=5


* 
persamaan kedua: 4y-3=-5


jadi, solusi dari persamaaan |4y-3|=5 adalah y=2 atau y=-1/2


\>$&solve(abs((4\*y-3)=5))


